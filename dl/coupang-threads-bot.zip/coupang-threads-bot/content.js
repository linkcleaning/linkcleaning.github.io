// =============================================
// 쿠팡 × 스레드 글봇 - content.js  (v1)
// 스레드 페이지 안에서 동작: 글 긁어오기 + 글쓰기 창 자동 입력
// ※ [게시] 버튼은 절대 누르지 않습니다. 확인 후 직접 눌러주세요.
// =============================================

if (!window.__coupangThreadsBotLoaded) {
  window.__coupangThreadsBotLoaded = true;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 화면에 실제로 보이는 요소인지
  function isVisible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
  }

  // 조건을 만족하는 요소가 나타날 때까지 기다리기
  async function waitFor(fn, timeout = 6000, step = 150) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  // ---------------------------------------------
  // 1) 레퍼런스 글 가져오기
  // ---------------------------------------------
  const NOISE = [
    /^\d+([.,]\d+)?\s*(천|만|K|M)?$/i,            // 숫자(좋아요 수 등)
    /^(좋아요|답글|리포스트|공유|인용|번역하기|번역 보기|더 보기|팔로우|Translate|See translation|Like|Reply|Repost|Share|Follow|More)$/i,
    /^\d+\s*(초|분|시간|일|주|개월|년)( 전)?$/,     // 3시간, 2일
    /^\d+\s*[smhdw]$/i,                           // 3h, 2d
    /^\d{4}[-.]\d{1,2}[-.]\d{1,2}\.?$/,           // 날짜
    /^·$/,
  ];

  function cleanPostText(raw) {
    const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);
    const kept = lines.filter((l) => !NOISE.some((re) => re.test(l)));
    // 첫 줄이 공백 없는 영문/숫자/._ 이면 아이디로 보고 제거
    if (kept.length > 1 && /^[a-z0-9._]{2,30}$/i.test(kept[0])) kept.shift();
    return kept.join("\n").trim();
  }

  function grabReference() {
    // 드래그로 선택한 글이 있으면 그걸 우선
    const sel = String(window.getSelection() || "").trim();
    if (sel.length >= 10) return sel.slice(0, 3000);

    // 게시물 후보들
    let posts = [...document.querySelectorAll('div[data-pressable-container="true"]')];
    if (!posts.length) posts = [...document.querySelectorAll("article")];
    posts = posts.filter(isVisible);
    if (!posts.length) return "";

    // 화면 가운데에 가장 가까운 게시물 선택
    const centerY = window.innerHeight / 2;
    let best = null;
    let bestDist = Infinity;
    for (const p of posts) {
      const r = p.getBoundingClientRect();
      if (r.bottom < 0 || r.top > window.innerHeight) continue;
      const mid = r.top + r.height / 2;
      const d = Math.abs(mid - centerY);
      if (d < bestDist) {
        bestDist = d;
        best = p;
      }
    }
    if (!best) return "";
    return cleanPostText(best.innerText || "").slice(0, 3000);
  }

  // ---------------------------------------------
  // 2) 글쓰기 창 찾기 / 열기
  // ---------------------------------------------
  function getDialogEditors() {
    const dialogs = [...document.querySelectorAll('div[role="dialog"]')].filter(isVisible);
    for (const d of dialogs.reverse()) {
      const eds = [...d.querySelectorAll('[contenteditable="true"]')].filter(isVisible);
      if (eds.length) return { dialog: d, editors: eds };
    }
    return null;
  }

  function findByText(root, regex, selector = "div, span, a, button") {
    const els = [...root.querySelectorAll(selector)].filter(isVisible);
    // 가장 안쪽(작은) 요소부터
    return els.reverse().find((el) => regex.test((el.innerText || el.textContent || "").trim()));
  }

  function clickable(el) {
    return el?.closest('a, button, [role="button"], [tabindex]') || el;
  }

  async function openComposer() {
    let found = getDialogEditors();
    if (found) return found;

    // (a) 피드 맨 위 "무슨 생각을 하고 계신가요?" 영역
    const trigger = findByText(
      document,
      /^(무슨 생각을 하고 계신가요\??|새로운 소식이 있나요\??|새로운 소식\??|What'?s new\??|Start a thread\.*|스레드를 시작하세요\.*)$/i,
      "div, span"
    );
    if (trigger) {
      clickable(trigger).click();
      found = await waitFor(getDialogEditors, 4000);
      if (found) return found;
    }

    // (b) 왼쪽/아래 메뉴의 "만들기(+)" 버튼
    const svg = [...document.querySelectorAll("svg[aria-label]")].find(
      (s) => /^(만들기|새 스레드|Create|New thread)$/i.test(s.getAttribute("aria-label")) && isVisible(s)
    );
    if (svg) {
      clickable(svg).click();
      found = await waitFor(getDialogEditors, 5000);
      if (found) return found;
    }
    return null;
  }

  // ---------------------------------------------
  // 3) 입력창에 글 넣기 (스레드 에디터 대응)
  // ---------------------------------------------
  function placeCaretAtEnd(el) {
    el.focus();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function editorText(el) {
    return (el.innerText || "").replace(/\s+/g, "");
  }

  async function insertText(el, text) {
    const probe = text.replace(/\s+/g, "").slice(0, 12);
    placeCaretAtEnd(el);
    await sleep(80);

    // 방법 1: 붙여넣기 이벤트 (줄바꿈이 가장 잘 유지됨)
    try {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch (e) {}
    await sleep(250);
    if (editorText(el).includes(probe)) return true;

    // 방법 2: insertText 명령 (줄 단위로)
    placeCaretAtEnd(el);
    const lines = text.split("\n");
    lines.forEach((line, i) => {
      if (line) document.execCommand("insertText", false, line);
      if (i < lines.length - 1) document.execCommand("insertParagraph");
    });
    await sleep(250);
    if (editorText(el).includes(probe)) return true;

    // 방법 3: 통째로 insertText
    placeCaretAtEnd(el);
    document.execCommand("insertText", false, text);
    await sleep(250);
    return editorText(el).includes(probe);
  }

  // ---------------------------------------------
  // 4) 본문 + 첫 댓글 채우기
  // ---------------------------------------------
  async function fill(body, comment) {
    const found = await openComposer();
    if (!found) {
      return { ok: false, message: "글쓰기 창을 열지 못했어요. 스레드 홈 화면에서 다시 시도하거나, 글쓰기 창을 직접 연 뒤 [다시 채우기]를 눌러주세요." };
    }

    let { dialog, editors } = found;
    const first = editors[0];

    // 이미 내용이 있으면 덮어쓰지 않고 알림
    if (editorText(first).length > 0 && !editorText(first).includes(body.replace(/\s+/g, "").slice(0, 12))) {
      return { ok: false, message: "글쓰기 창에 이미 다른 내용이 있어요. 지우고 다시 눌러주세요." };
    }

    if (!editorText(first).length) {
      const ok1 = await insertText(first, body);
      if (!ok1) return { ok: false, message: "본문 자동 입력에 실패했어요." };
    }
    if (!comment) return { ok: true };

    await sleep(400);

    // "스레드에 추가" 눌러서 두 번째 칸 만들기
    let current = getDialogEditors();
    let eds = current ? current.editors : editors;
    if (eds.length < 2) {
      const addBtn = findByText(
        current ? current.dialog : dialog,
        /^(스레드에 추가|스레드에 추가하기|Add to thread)$/i,
        "div, span, button"
      );
      if (!addBtn) {
        return { ok: false, message: "본문은 입력했어요. '스레드에 추가' 버튼을 못 찾았으니 댓글은 [댓글 복사]로 붙여넣어 주세요." };
      }
      clickable(addBtn).click();
      const res = await waitFor(() => {
        const g = getDialogEditors();
        return g && g.editors.length >= 2 ? g : null;
      }, 4000);
      if (!res) {
        return { ok: false, message: "본문은 입력했어요. 두 번째 칸이 안 열려서 댓글은 [댓글 복사]로 붙여넣어 주세요." };
      }
      eds = res.editors;
    }

    const last = eds[eds.length - 1];
    if (!editorText(last).length) {
      const ok2 = await insertText(last, comment);
      if (!ok2) return { ok: false, message: "본문은 입력했어요. 댓글 칸 입력은 실패했으니 [댓글 복사]를 써주세요." };
    }

    // 맨 위 본문이 보이도록
    first.scrollIntoView({ block: "center", behavior: "smooth" });
    return { ok: true };
  }

  // ---------------------------------------------
  // 팝업과 대화
  // ---------------------------------------------
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.action === "grab") {
      sendResponse({ text: grabReference() });
      return false;
    }
    if (msg?.action === "fill") {
      fill(msg.body || "", msg.comment || "")
        .then(sendResponse)
        .catch((e) => sendResponse({ ok: false, message: String(e?.message || e) }));
      return true; // 비동기 응답
    }
    return false;
  });
}
