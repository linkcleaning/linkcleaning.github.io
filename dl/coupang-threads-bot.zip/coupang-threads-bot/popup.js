// =============================================
// 쿠팡 × 스레드 글봇 - popup.js  (v1)
// =============================================

const DISCLOSURE =
  "이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.";
const THREADS_MAX = 500; // 스레드 글 1개당 글자 수 제한

const TONES = {
  friend: {
    name: "친근한 꿀템 추천형",
    guide:
      "친구한테 카톡하듯 반말과 음슴체를 섞어서 써. 가볍고 솔직한 느낌. '이거 진짜 물건임', '나만 몰랐냐' 같은 리듬.",
    cta: "정보는 댓글에 남겨뒀어 👇",
  },
  expert: {
    name: "살림·청소 전문가 꿀팁형",
    guide:
      "살림·청소를 오래 해온 사람이 노하우를 알려주는 말투. 존댓말이지만 딱딱하지 않게, '이렇게 쓰면 훨씬 편해요' 같은 실용 꿀팁 위주.",
    cta: "제품 정보는 댓글에 정리해뒀어요 👇",
  },
  hype: {
    name: "호기심 유발 품절대란형",
    guide:
      "첫 줄에서 궁금증을 확 끌어올리는 말투. '이거 왜 다들 쟁여두는지 알겠음', '알고 나면 못 돌아감' 같은 훅. 단, 실제로 품절이라고 단정하지 말 것.",
    cta: "뭔지 궁금하면 댓글 확인 👇",
  },
};

const $ = (id) => document.getElementById(id);

// ---------- 상태 메시지 ----------
function setStatus(msg, type = "") {
  const el = $("status");
  el.textContent = msg;
  el.className = type;
}

// ---------- 저장/불러오기 ----------
async function loadAll() {
  const d = await chrome.storage.local.get([
    "apiKey", "model", "reference", "link", "tone", "adTag", "lastBody", "lastComment",
  ]);
  if (d.apiKey) {
    $("apiKey").value = d.apiKey;
    $("keyState").textContent = "✓ 저장됨";
  } else {
    $("keyBox").open = true; // 키 없으면 펼쳐두기
  }
  if (d.model) $("model").value = d.model;
  if (d.reference) $("reference").value = d.reference;
  if (d.link) $("link").value = d.link;
  if (d.tone) {
    const r = document.querySelector(`input[name="tone"][value="${d.tone}"]`);
    if (r) r.checked = true;
  }
  if (typeof d.adTag === "boolean") $("adTag").checked = d.adTag;
  if (d.lastBody || d.lastComment) showResult(d.lastBody || "", d.lastComment || "");
}

function saveDraft() {
  chrome.storage.local.set({
    reference: $("reference").value,
    link: $("link").value,
    tone: getTone(),
    adTag: $("adTag").checked,
    model: $("model").value,
  });
}

function getTone() {
  return document.querySelector('input[name="tone"]:checked').value;
}

// ---------- 결과 표시 ----------
function updateCount(textId, cntId) {
  const n = $(textId).value.length;
  const el = $(cntId);
  el.textContent = `${n} / ${THREADS_MAX}자`;
  el.className = "count" + (n > THREADS_MAX ? " over" : "");
}

function showResult(body, comment) {
  $("outBody").value = body;
  $("outComment").value = comment;
  $("result").style.display = "block";
  updateCount("outBody", "cntBody");
  updateCount("outComment", "cntComment");
}

// ---------- 현재 탭 ----------
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isThreads(url = "") {
  return /^https:\/\/(www\.)?threads\.(net|com)\//.test(url);
}

// 콘텐츠 스크립트에 메시지 보내기 (안 붙어 있으면 주입 후 재시도)
async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await new Promise((r) => setTimeout(r, 150));
    return await chrome.tabs.sendMessage(tabId, message);
  }
}

// ---------- Gemini 호출 ----------
function buildPrompt(reference, toneKey) {
  const t = TONES[toneKey];
  const system = `너는 한국 스레드(Threads)에서 조회수가 잘 나오는 글을 쓰는 카피라이터야.
아래 규칙을 반드시 지켜.

[본문 규칙]
- 3~5줄. 한 줄마다 줄바꿈. 한 줄은 짧게(모바일에서 한눈에).
- 첫 줄은 스크롤을 멈추게 하는 강한 훅.
- 이모지는 2~4개만 자연스럽게.
- 말투: ${t.guide}
- 마지막 줄은 반드시 댓글을 열어보게 만드는 유도 문구. 예: "${t.cta}"
- 본문에는 링크, URL, '쿠팡', 가격, 할인율, 해시태그를 넣지 마.
- 참고 글이 주어지면 구조와 리듬만 참고하고 문장을 그대로 베끼지 마.
- '최저가', '품절', '의학적 효과', '100%' 같은 확인 안 된 단정은 금지.
- 참고 내용에 없는 구체적인 사용 기간·구매 경험(예: "3달째 쓰는 중")은 지어내지 마.

[summary 규칙]
- 첫 번째 댓글 맨 위에 들어갈 상품 한 줄 요약. 25자 안팎, 이모지 1개.
- 예: "🧴 바르고 닦기만 하는 욕실 곰팡이 젤"

결과는 JSON으로만: {"body": "본문", "summary": "한 줄 요약"}`;

  const user = `[상품명 / 참고 내용]\n${reference}`;
  return { system, user };
}

async function callGemini(apiKey, model, system, user) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const payload = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: "user", parts: [{ text: user }] }],
    generationConfig: {
      temperature: 0.95,
      responseMimeType: "application/json",
      responseSchema: {
        type: "OBJECT",
        properties: {
          body: { type: "STRING" },
          summary: { type: "STRING" },
        },
        required: ["body", "summary"],
      },
      thinkingConfig: { thinkingBudget: 0 },
    },
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("") || "";
  if (!text) throw new Error("AI가 빈 응답을 보냈어요. 다시 눌러주세요.");

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    const m = text.match(/\{[\s\S]*\}/);
    parsed = m ? JSON.parse(m[0]) : null;
  }
  if (!parsed?.body) throw new Error("AI 응답을 읽지 못했어요. 다시 눌러주세요.");
  return parsed;
}

// ---------- 결과 다듬기 ----------
function cleanBody(body, toneKey, adTag) {
  let b = String(body)
    .replace(/https?:\/\/\S+/g, "") // 혹시 들어간 링크 제거
    .replace(/\r/g, "")
    .split("\n")
    .map((l) => l.trim())
    .filter((l, i, arr) => l !== "" || (i > 0 && arr[i - 1] !== ""))
    .join("\n")
    .trim();

  // 댓글 유도 문구가 없으면 붙이기
  if (!/댓글|👇/.test(b)) b += "\n" + TONES[toneKey].cta;

  if (adTag && !/^\(광고\)/.test(b)) b = "(광고) " + b;

  if (b.length > THREADS_MAX) b = b.slice(0, THREADS_MAX - 1) + "…";
  return b;
}

function buildComment(summary, link) {
  const s = String(summary || "").replace(/https?:\/\/\S+/g, "").trim();
  return `${s}\n\n👉 ${link.trim()}\n\n${DISCLOSURE}`;
}

// ---------- 스레드에 채우기 ----------
async function fillThreads(body, comment) {
  const tab = await getActiveTab();
  if (!tab || !isThreads(tab.url)) {
    setStatus("✅ 글 완성! 지금 탭이 스레드가 아니라서 자동 입력은 건너뛰었어요.\n아래 [본문 복사] / [댓글 복사] 버튼을 쓰세요.", "ok");
    return;
  }
  setStatus("✍️ 스레드 글쓰기 창에 입력하는 중...");
  try {
    const r = await sendToTab(tab.id, { action: "fill", body, comment });
    if (r?.ok) {
      setStatus("✅ 입력 완료! 스레드 화면에서 내용 확인 후 [게시]만 누르세요.", "ok");
    } else {
      setStatus(`⚠️ ${r?.message || "자동 입력 실패"}\n아래 복사 버튼으로 붙여넣어 주세요.`, "err");
    }
  } catch (e) {
    setStatus("⚠️ 스레드 페이지와 연결이 안 됐어요. 스레드 탭을 새로고침(F5)한 뒤 [다시 채우기]를 눌러주세요.", "err");
  }
}

// ---------- 버튼: 키 저장 ----------
$("saveKey").addEventListener("click", async () => {
  const key = $("apiKey").value.trim();
  if (!key) return setStatus("API 키를 입력해주세요.", "err");
  await chrome.storage.local.set({ apiKey: key, model: $("model").value });
  $("keyState").textContent = "✓ 저장됨";
  $("keyBox").open = false;
  setStatus("🔑 API 키를 저장했어요. 다음부터는 입력 안 해도 돼요.", "ok");
});

$("model").addEventListener("change", () => chrome.storage.local.set({ model: $("model").value }));

// ---------- 버튼: 레퍼런스 가져오기 ----------
$("grabBtn").addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!tab || !isThreads(tab.url)) {
    return setStatus("스레드(threads.com) 탭을 열어둔 상태에서 눌러주세요.", "err");
  }
  setStatus("📥 글을 가져오는 중...");
  try {
    const r = await sendToTab(tab.id, { action: "grab" });
    if (r?.text) {
      $("reference").value = r.text;
      saveDraft();
      setStatus(`📥 가져왔어요 (${r.text.length}자). 필요하면 상품명을 덧붙여 주세요.`, "ok");
    } else {
      setStatus("화면에서 글을 찾지 못했어요. 글을 화면 가운데 오게 하거나, 드래그로 선택한 뒤 다시 눌러주세요.", "err");
    }
  } catch (e) {
    setStatus("스레드 탭을 새로고침(F5)한 뒤 다시 눌러주세요.", "err");
  }
});

// ---------- 버튼: 생성 + 채우기 ----------
$("genBtn").addEventListener("click", async () => {
  const { apiKey } = await chrome.storage.local.get("apiKey");
  const reference = $("reference").value.trim();
  const link = $("link").value.trim();
  const toneKey = getTone();

  if (!apiKey) {
    $("keyBox").open = true;
    return setStatus("먼저 Gemini API 키를 저장해주세요.", "err");
  }
  if (!reference) return setStatus("상품명이나 참고 내용을 입력해주세요.", "err");
  if (!link) return setStatus("쿠팡파트너스 링크를 붙여넣어 주세요.", "err");
  if (!/^https?:\/\//.test(link)) return setStatus("링크는 https:// 로 시작해야 해요.", "err");
  if (!/coupang\.com|coupa\.ng/.test(link)) {
    if (!confirm("쿠팡 링크가 아닌 것 같아요. 그래도 진행할까요?")) return;
  }

  saveDraft();
  const btn = $("genBtn");
  btn.disabled = true;
  btn.textContent = "⏳ AI가 글 쓰는 중...";
  setStatus("Gemini가 본문과 댓글을 만드는 중이에요 (5~10초)");

  try {
    let model = $("model").value;
    const { system, user } = buildPrompt(reference, toneKey);
    let out;
    try {
      out = await callGemini(apiKey, model, system, user);
    } catch (e) {
      // 모델 과부하/미지원이면 lite로 한 번 더
      if ([404, 429, 500, 503].includes(e.status) && model !== "gemini-2.5-flash-lite") {
        setStatus("기본 모델이 바빠서 다른 모델로 다시 시도 중...");
        out = await callGemini(apiKey, "gemini-2.5-flash-lite", system, user);
      } else throw e;
    }

    const body = cleanBody(out.body, toneKey, $("adTag").checked);
    const comment = buildComment(out.summary, link);
    showResult(body, comment);
    await chrome.storage.local.set({ lastBody: body, lastComment: comment });

    await fillThreads(body, comment);
  } catch (e) {
    let msg = e.message || String(e);
    if (/API key not valid|API_KEY_INVALID/i.test(msg)) msg = "API 키가 올바르지 않아요. 키를 다시 확인해주세요.";
    else if (e.status === 429) msg = "무료 사용량을 잠시 초과했어요. 1분 뒤 다시 눌러주세요.";
    setStatus("❌ " + msg, "err");
  } finally {
    btn.disabled = false;
    btn.textContent = "✨ AI 글 생성 + 스레드 자동 채우기";
  }
});

// ---------- 버튼: 다시 채우기 ----------
$("refillBtn").addEventListener("click", async () => {
  const body = $("outBody").value.trim();
  const comment = $("outComment").value.trim();
  if (!body) return setStatus("채울 내용이 없어요.", "err");
  await chrome.storage.local.set({ lastBody: body, lastComment: comment });
  await fillThreads(body, comment);
});

// ---------- 버튼: 복사 ----------
document.querySelectorAll(".copy").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const text = $(btn.dataset.target).value;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = $(btn.dataset.target);
      ta.select();
      document.execCommand("copy");
    }
    const old = btn.textContent;
    btn.textContent = "✓ 복사됨";
    btn.classList.add("done");
    setTimeout(() => {
      btn.textContent = old;
      btn.classList.remove("done");
    }, 1200);
  });
});

// ---------- 입력할 때마다 자동 저장 ----------
["reference", "link"].forEach((id) => $(id).addEventListener("input", saveDraft));
document.querySelectorAll('input[name="tone"]').forEach((r) => r.addEventListener("change", saveDraft));
$("adTag").addEventListener("change", saveDraft);
$("outBody").addEventListener("input", () => {
  updateCount("outBody", "cntBody");
  chrome.storage.local.set({ lastBody: $("outBody").value });
});
$("outComment").addEventListener("input", () => {
  updateCount("outComment", "cntComment");
  chrome.storage.local.set({ lastComment: $("outComment").value });
});

loadAll();
